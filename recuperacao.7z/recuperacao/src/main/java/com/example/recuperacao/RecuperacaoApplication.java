package com.example.recuperacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecuperacaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecuperacaoApplication.class, args);
	}

}
